
# Make/Zapier - Workflows

1) Lead Intake (Syllabus)
Trigger: Form submission (MailerLite/Brevo) ->
Actions: Create/Update Contact (CRM) + Apply tags + Add to Group 'Welcome' ->
Send WhatsApp via WABA (se opt-in) ->
Append row to Google Sheet (log) ->
Slack alert 'Nuovo lead'.

2) Webinar Registration Sync
Trigger: Click CTA webinar (UTM) / Tool webinar (Zoom/Meet/WebinarJam) ->
Actions: Update contact field webinar_status=registered ->
Schedule reminders (24h/15m) su WABA + Email ICS.

3) Post-Webinar Segmentation
Trigger: Fine evento (export attendees) ->
Actions: Calcolo show-time -> tag intent (high/mid/low) ->
Branch: High -> invia offerta consulenza; Mid -> invia replay + FAQ; Low -> invia case study.

4) Error Handling & Logs
Trigger: Scenario error ->
Actions: Retry 2x (exponential) -> if fail -> Slack + fallback email al lead.
